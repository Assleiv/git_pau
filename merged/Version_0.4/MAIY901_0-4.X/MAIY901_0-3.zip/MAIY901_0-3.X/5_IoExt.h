#ifndef IOEX_H
#define IOEX_H

/*******************************************************************************
*                               DEFINES                                        *
********************************************************************************
*		SETTINGS        *
************************/
// <editor-fold defaultstate="collapsed" desc="">

// </editor-fold>
/************************
*		FIXED           *
************************/
// <editor-fold defaultstate="collapsed" desc="">
#define _EXT_O1         LATBbits.LATB15
#define _EXT_O2         LATBbits.LATB14
#define _EXT_O3         LATBbits.LATB13
#define _EXT_O4         LATBbits.LATB12
#define _EXT_I1         PORTFbits.RF2
#define _EXT_I2         PORTFbits.RF3
#define _EXT_I3         PORTFbits.RF5
#define _EXT_I4         PORTFbits.RF4
// </editor-fold>
/*******************************************************************************
*		                   VARIABLES GLOBALES                                  *
*******************************************************************************/
// <editor-fold defaultstate="collapsed" desc="">

// </editor-fold>
/*******************************************************************************
*                               FONCTIONS                                      *
*******************************************************************************/
// <editor-fold defaultstate="collapsed" desc="">
extern void TASK5(void);
// </editor-fold>

#endif