#ifndef NOY_H
#define NOY_H

/*******************************************************************************
*                               DEFINES                                        *
********************************************************************************
*		SETTINGS        *
************************/
// <editor-fold defaultstate="collapsed" desc="">
#define OSC_FREQ    32000   //fr�quence OSC en kHz, attention il ne s'agit pas ici d'un param�tre mais d'une info pour les autres taches
#define _XTAL_FREQ  32000000    // idem mais en Hz (n�cessaire � la fonction delay)
#define EEPROM_USINE    // si d�comment�, le flashage de la carte r��crit toute l'EEPROM selon les valeurs du code
#define VREF        3.33 // tension de reference (pour adc)
#define ADC_MAX     1023    //10bits (pour calcul des tensions)
// </editor-fold>
/************************
*		FIXED           *
************************/
// <editor-fold defaultstate="collapsed" desc="">
//STATE T�ches
#define READY	0
#define WAIT	1
#define HALTE	2
//PHASE T�ches
#define AMBRION     0
#define INITIALIZED 1
#define ENCOURS     2
#define ENDEFAUT    3
#define END         4
//ID T�ches
#define TASK0_ID    0
#define TASK1_ID	1
#define TASK2_ID	2
#define TASK3_ID	3
#define TASK4_ID	4
#define TASK5_ID	5
#define TASK6_ID	6
#define TASK7_ID	7
#define TASK8_ID	8
#define TASK9_ID	9
//Nb T�ches
#define NB_TASK     10
// </editor-fold>
/*******************************************************************************
*		                   VARIABLES GLOBALES                                  *
*******************************************************************************/
// <editor-fold defaultstate="collapsed" desc="">
typedef struct 
{
	unsigned char STATE;
	unsigned int DELAY;
	unsigned char STEP;
    unsigned char PHASE;
}STR_TASK;
extern volatile STR_TASK TASK[NB_TASK];
// </editor-fold>
/*******************************************************************************
*                               FONCTIONS                                      *
*******************************************************************************/
// <editor-fold defaultstate="collapsed" desc="">
extern void SET_READY(unsigned char x);
extern void SET_STOP(unsigned char x);
extern void SET_WAIT(unsigned char x, unsigned int y);
extern void Init_Osc(void);  // initialisation de l'oscillateur
extern void Init_Pins(void); // initialisation des I/O microcontr�leur
extern void Init_Interrupt(void);    // initialisation des interruptions
extern void Init_Tasks(void);    //Configuration parametres taches au demarrage
extern void Init_Adc(void);     // initialisation du module adc
extern unsigned int ReadAdc(unsigned char channel); //fonction de lecture adc
// </editor-fold>
#endif